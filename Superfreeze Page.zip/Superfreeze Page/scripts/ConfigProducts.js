//Zeigt angeklickte Zone an
function showInfo(ident) {
  document.getElementById("ZoneText").style.display = "block";
  document.getElementById("TZoneID").textContent = 'Zone ' + ident;
}

// Produktinventar
  var Produkt = {};
  //Produkt entfernen
  function removeProd(){
    var rowNumber = prompt("Geben Sie die Produkt ID des zu löschenden Produkts ein");
    document.getElementById(rowNumber).remove();
    alert("Zeile " + rowNumber + " wurde entfernt.");
  }

  var incrementId = 0;
  //Produkt hinzufügen
  function addProd(){
    incrementId++;

    while (true){
    var prodName = prompt('Wie nennt sich das neue Produkt?');
      if (prodName == '') {
        alert ("Diese Information darf nicht fehlen.");
      } else {
        break;
      }
    }
    while (true) {
    var prodAnzahl = prompt('Wie viele Exemplare des Produkts möchten Sie registrieren?');
      if (prodAnzahl <= 0) {
        alert ("Sie müssen eine Zahl über 0 eingeben.");
      } else {
        break;
      }
    }
    while (true){
    var prodPreis = prompt('Wie viel kostet das Produkt pro Stück?');
    if (prodPreis == '') {
        alert ("Diese Information darf nicht fehlen.");
      } else {
        break;
      }
    }
    while (true) {
      var prodADatum = prompt('Bitte geben Sie das Verfalldatum ein.');
      if (prodADatum == '') {
        alert ("Diese Information darf nicht fehlen.");
      } else {
        break;
      }
    }

    //JSON Objekt Array erstelelen
    Produkt[incrementId] = {
    id: incrementId,
    name: prodName,
    anzahl: prodAnzahl,
    preis: prodPreis,
    datum: prodADatum
    }

    var table = document.getElementById("t1");
    var row = table.insertRow(-1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);

    cell1.innerHTML = prodName;
    cell2.innerHTML = prodAnzahl;
    cell3.innerHTML = prodPreis;
    cell4.innerHTML = prodADatum;
    cell5.innerHTML = incrementId;

    row.id = incrementId;
    alert('Sie haben erfolgreich ' + prodAnzahl + 'Mal ' + prodName + ' hinzugefügt.');

    return incrementId;
  }
