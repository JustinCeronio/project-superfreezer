//Varible für inkrementierende ID
var freezerId = 0;

// ==== Kühler hinzufügen ====
function addFreezer() {
  freezerId++;
  //Daten abfragen //Zum Exportieren
  while(true) {
    var freezerTyp = prompt('Welcher Typ hat euer Freezer? (1/2)');
    if (freezerTyp == 1 || freezerTyp == 2) {
      break;
    } else {
      alert("Freezertyp ungültig");
    }
  }
  while(true) {
    var freezerZonenAnzahl = prompt('Wieviele Zonen hat Ihr Kühler?');
    if (freezerZonenAnzahl <= 8 && freezerZonenAnzahl > 0) {
      break;
    } else {
      alert("Zonenanzahl ungültig");
    }
  }


  //Zeileneintrag in die erste Tabelle machen
  var table = document.getElementById("t1");
  var row = table.insertRow(-1); // Neue Zeile
  var cell1 = row.insertCell(0); // Name

  //Zeileneintrag in die zweite Tabelle machen
  var tableTwo = document.getElementById("t2");
  var rowTwo = tableTwo.insertRow(-1); // Neue Zeile
  var cell1Two = rowTwo.insertCell(0); // Name
  var cell2Two = rowTwo.insertCell(1); // Typ
  var cell3Two = rowTwo.insertCell(2); // Zonenanzahl

  //Spalten in die zweite Tabelle abfüllen
  var freezerNameID = "Freezer " + freezerId;
  cell1Two.innerHTML = freezerNameID;
  cell2Two.innerHTML = freezerTyp;
  cell3Two.innerHTML = freezerZonenAnzahl;

  //Auf Click der Spalte rechts entsprechende Config anzeigen lassen
  row.onclick = function() {
    document.getElementById("DetailsButton").style.display = "inline";
    frText(row.id, freezerZonenAnzahl);
  };

  //ID setzen
  var cell2 = row.insertCell(1);
  var cell4Two = rowTwo.insertCell(3);
  cell1.innerHTML = "Freezer " + freezerId;
  cell2.innerHTML = freezerId;
  cell4Two.innerHTML = freezerId;
  row.id = freezerId;
  rowTwo.id = freezerId;

  //FreezerID zurückgeben
  return freezerId;
}

// ==== Kühler entfernen ====
function removeFreezer() {
  //Holt ID vom User
  var idOne = prompt("Geben Sie die ID des zu löschenden Freezers ein");
  var idTwo = idOne;
  //Entfernt Tabelle mit der entsprechender ID
  document.getElementById(idOne).remove();
  document.getElementById(idTwo).remove();

}

//Zeigt Konfigurationen der entsprechenden Zonen an
function frText(id, zonenAnzahl) {
  var FreezerText = "Sie haben " + zonenAnzahl + " Zonen";

  //Inhalt wird angezeigt
  freezerIDZonenAnzahl = zonenAnzahl;
  freezerIDName = id;
  document.getElementById("target").innerHTML = FreezerText;
};

//Tabelle verstecken
function toggleRow() {
 if( document.getElementById("hidethis").style.display=='none' ){
   document.getElementById("hidethis").style.display = '';
 }else{
   document.getElementById("hidethis").style.display = 'none';
 }
}

function openDetails() {
  window.location.href = "freezerdetails.html?" + freezerIDZonenAnzahl;
}
