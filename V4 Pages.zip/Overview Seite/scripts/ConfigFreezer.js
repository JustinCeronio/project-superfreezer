//Varible für inkrementierende ID
var freezerId = 0;

// ==== Kühler hinzufügen ====
function addFreezer() {
  //ID Inkrementieren
  freezerId++;

  //Daten abfragen //Zum Exportieren
  var freezerName = prompt('Wie nennt sich das neue Produkt?');
  var freezerAnzahl = prompt('Wie viele Exemplare des Produkts möchten Sie registrieren?');
  var freezerPreis = prompt('Wie viel kostet das Produkt pro Stück?');
  var freezerTyp = prompt('Welcher Typ ist ihr Kühler?');

  //Zeileneintrag in die erste Tabelle machen
  var table = document.getElementById("t1");
  var row = table.insertRow(-1); // Neue Zeile
  var cell1 = row.insertCell(0); // Name
  var cell2 = row.insertCell(1); // ID

  //Zeileneintrag in die zweite Tabelle machen
  var tableTwo = document.getElementById("t2");
  var rowTwo = tableTwo.insertRow(-1); // Neue Zeile
  var cell1Two = rowTwo.insertCell(0); // Name
  var cell2Two = rowTwo.insertCell(1); // Anzahl
  var cell3Two = rowTwo.insertCell(2); // Typ
  var cell4Two = rowTwo.insertCell(3); // Preis
  var cell5Two = rowTwo.insertCell(4); // ID

  //Spalten in die erste Tabelle abfüllen
  cell1.innerHTML = freezerName;
  cell2.innerHTML = freezerId;

  //Spalten in die zweite Tabelle abfüllen
  cell1Two.innerHTML = freezerName;
  cell2Two.innerHTML = freezerAnzahl;
  cell3Two.innerHTML = freezerTyp;
  cell4Two.innerHTML = freezerPreis;
  cell5Two.innerHTML = freezerId;

  //Temporäre ID als SpaltenID setzen
  row.id = freezerId;
  rowTwo.id = "tableTwo" + freezerId;

  //Zweite Tabelle verstecken
  rowTwo.style="display:none;"

  //Auf Click der Spalte rechts entsprechende Config anzeigen lassen
  row.onclick = function() {frText(row.id);};

  //FreezerID zurückgeben
  return freezerId;
}

// ==== Kühler entfernen ====
function removeFreezer() {
  //Holt ID vom User
  var idOne = prompt("Geben Sie die ID des zu löschenden Freezers ein");
  var idTwo = "tableTwo" + idOne;
  //Entfernt Tabelle mit der entsprechender ID
  document.getElementById(idOne).remove();
  document.getElementById(idTwo).remove();

}

//Tabelle verstecken
function toggleRow(idTwo) {
 if(document.getElementById("tableTwo" + idTwo).style.display = 'none' ){
   document.getElementById("tableTwo" + idTwo).style.display = '';
 } else{
   document.getElementById("tableTwo" + idTwo).style.display = 'none';
 }
}

//Zeigt Konfigurationen der entsprechenden Zonen an
function frText(id) {

switch (id) {
  case "1":
    toggleRow(id);

    break;
  case "2":
    toggleRow(id);

    break;
  case "3":
    toggleRow(id);

    break;
  case "4":
    toggleRow(id);

    break;
  case "5":
  toggleRow(id);

    break;
  case "6":
  toggleRow(id);

    break;

  default: FreezerText = "Kein Freezer ausgewählt."
  }


  //Inhalt wird angezeigt
  document.getElementById("target").innerHTML = FreezerText;
};
